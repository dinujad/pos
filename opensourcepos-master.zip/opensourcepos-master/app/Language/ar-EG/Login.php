<?php
return [
	"gcaptcha" => "أنا لست بوت.",
	"go" => "البدء",
	"invalid_gcaptcha" => "يرجى التأكيد على أنك لست روبوتا.",
	"invalid_installation" => "يوجد مشكلة بالتنصيب, الرجاء التحقق من ملف php.ini.",
	"invalid_username_and_password" => "اسم مستخدم/كلمة سر غير صحيح.",
	"login" => "دخول",
	"logout" => "تسجيل خروج",
	"migration_needed" => "سيبدأ ترحيل قاعدة البيانات إلى{0} بعد تسجيل الدخول.",
	"password" => "كلمة السر",
	"required_username" => "",
	"username" => "اسم المستخدم",
	"welcome" => "مرحباً بك في{0}!",
];
