<?php
return [
	"first_name" => "First name",
	"last_name" => "Last name",
	"message" => "Message",
	"message_placeholder" => "Your Message here...",
	"message_required" => "Message required",
	"multiple_phones" => "(In case of multiple recipients, enter mobile numbers separated by commas)",
	"phone" => "Phone number",
	"phone_number_required" => "Phone number required",
	"phone_placeholder" => "Mobile Number(s) here...",
	"sms_send" => "Send SMS",
	"successfully_sent" => "Message successfully sent to: ",
	"unsuccessfully_sent" => "Message unsuccessfully sent to: ",
];
