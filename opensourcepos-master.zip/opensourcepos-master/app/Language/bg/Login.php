<?php
return [
	"gcaptcha" => "Не съм робот.",
	"go" => "Go",
	"invalid_gcaptcha" => "Invalid I'm not a robot.",
	"invalid_installation" => "The installation is not correct, check your php.ini file.",
	"invalid_username_and_password" => "Invalid Username or Password.",
	"login" => "Login",
	"logout" => "",
	"migration_needed" => "",
	"password" => "Password",
	"required_username" => "",
	"username" => "Username",
	"welcome" => "",
];
