<?php
return [
	"no_permission_module" => "Нямате разрешение за достъп до модула с име",
	"unknown" => "Неизвестна грешка",
];
