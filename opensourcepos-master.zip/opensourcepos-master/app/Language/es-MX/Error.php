<?php
return [
	"no_permission_module" => "No tienes permiso para acceder el módulo llamado",
	"unknown" => "Error inesperado",
];
