<?php
return [
	"all" => "Todos",
	"columns" => "Columnas",
	"hide_show_pagination" => "Ocultar/Mostrar paginación",
	"loading" => "Cargando, por favor espere...",
	"page_from_to" => "Mostrando de {0} a {1} de {2} registros",
	"refresh" => "Actualizar",
	"rows_per_page" => "{0} registros por página",
	"toggle" => "Establecer",
];
