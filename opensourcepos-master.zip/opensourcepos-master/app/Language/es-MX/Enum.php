<?php
return [
	"half_down" => "Mitad abajo",
	"half_even" => "Mitad par",
	"half_five" => "Cinco y media",
	"half_odd" => "Mitad impar",
	"half_up" => "Medio arriba",
	"round_down" => "Truncado",
	"round_up" => "Redondeo arriba",
];
