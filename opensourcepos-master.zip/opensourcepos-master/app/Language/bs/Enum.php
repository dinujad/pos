<?php
return [
	"half_down" => "Pola dolje",
	"half_even" => "Pola ravnomjerno",
	"half_five" => "Pola na pet",
	"half_odd" => "Pola neparno",
	"half_up" => "Pola gore",
	"round_down" => "Zaokruži naniže",
	"round_up" => "Zaokruži naviše",
];
