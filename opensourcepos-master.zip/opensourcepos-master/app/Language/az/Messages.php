<?php
return [
	"first_name" => "Adı",
	"last_name" => "Soyadı",
	"message" => "Mesaj",
	"message_placeholder" => "Mesajınız burada...",
	"message_required" => "Mesaj tələb olunur",
	"multiple_phones" => "(Birdən çox alıcı halında, vergüllə ayrılan mobil nömrələri daxil edin)",
	"phone" => "Telefon",
	"phone_number_required" => "Telefon nömrəsi tələb olunur",
	"phone_placeholder" => "Mobil Nömrə(lər) burada...",
	"sms_send" => "SMS Göndər",
	"successfully_sent" => "Mesaj uğurla göndərildi: ",
	"unsuccessfully_sent" => "Mesaj uğursuz olaraq göndərildi: ",
];
