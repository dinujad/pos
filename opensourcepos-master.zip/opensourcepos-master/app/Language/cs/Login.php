<?php
return [
	"gcaptcha" => "Nejsem robot.",
	"go" => "Přihlásit",
	"invalid_gcaptcha" => "Špatné zadání.",
	"invalid_installation" => "Instalace není v pořádku, zkontrolujte soubor php.ini.",
	"invalid_username_and_password" => "Neplatné jméno nebo heslo.",
	"login" => "Login",
	"logout" => "",
	"migration_needed" => "",
	"password" => "Heslo",
	"required_username" => "",
	"username" => "Uživatelské jméno",
	"welcome" => "",
];
